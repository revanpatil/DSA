package com.project.hackernews;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HackernewsApplicationTests {

    @Test
    void contextLoads() {
    }

}
